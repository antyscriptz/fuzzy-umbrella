import SwiftUI
import WebKit
import UIKit

@main
struct AntysSaveEditorApp: App {
    var body: some Scene {
        WindowGroup { EditorWebView() }
    }
}

struct EditorWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.userContentController.add(context.coordinator, name: "saveExport")
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        context.coordinator.webView = webView
        if let root = Bundle.main.resourceURL?.appendingPathComponent("WebApp", isDirectory: true),
           FileManager.default.fileExists(atPath: root.appendingPathComponent("index.html").path) {
            webView.loadFileURL(root.appendingPathComponent("index.html"), allowingReadAccessTo: root)
        } else {
            webView.loadHTMLString("<h2>Anty's Save Editor</h2><p>App assets are missing. Rebuild the app with the WebApp folder included.</p>", baseURL: nil)
        }
        webView.isOpaque = false
        webView.backgroundColor = .white
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
        weak var webView: WKWebView?

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "saveExport", let payload = message.body as? [String: Any],
                  let filename = payload["filename"] as? String,
                  let base64 = payload["base64"] as? String,
                  let data = Data(base64Encoded: base64) else { return }
            let safeName = URL(fileURLWithPath: filename).lastPathComponent
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            do {
                try data.write(to: url, options: .atomic)
                DispatchQueue.main.async { self.presentShareSheet(for: url) }
            } catch {
                DispatchQueue.main.async { self.showError("Could not prepare export: \(error.localizedDescription)") }
            }
        }

        private func presentShareSheet(for url: URL) {
            guard let view = webView, let presenter = view.window?.rootViewController else { return }
            let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            if let popover = sheet.popoverPresentationController {
                popover.sourceView = view
                popover.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
            }
            topPresenter(from: presenter).present(sheet, animated: true)
        }

        private func topPresenter(from controller: UIViewController) -> UIViewController {
            if let presented = controller.presentedViewController { return topPresenter(from: presented) }
            if let nav = controller as? UINavigationController, let visible = nav.visibleViewController { return topPresenter(from: visible) }
            if let tab = controller as? UITabBarController, let selected = tab.selectedViewController { return topPresenter(from: selected) }
            return controller
        }

        private func showError(_ message: String) {
            guard let presenter = webView?.window?.rootViewController else { return }
            let alert = UIAlertController(title: "Save Editor", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            topPresenter(from: presenter).present(alert, animated: true)
        }
    }
}
