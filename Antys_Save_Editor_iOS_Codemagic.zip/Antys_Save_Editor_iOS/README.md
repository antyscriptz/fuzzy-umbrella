# Anty's Save Editor — iOS wrapper project

This Xcode project wraps the focused Anty's Save Editor web app in a local WKWebView. It includes the currency/resource, power-up, plant editing, import, and export interface from the focused edition.

## Build and sideload

1. Open `AntysSaveEditor.xcodeproj` on a Mac with Xcode 15 or newer.
2. Select the `AntysSaveEditor` target and set your own unique Bundle Identifier under Signing & Capabilities.
3. Select your Apple Development team. For sideloading, use the signing flow supported by your sideloading tool and Apple account.
4. Build for a real iPhone. The web app is bundled locally; no web server is needed.
5. Exporting `pp.dat` and making the original backup uses the iOS share sheet, where you can choose Save to Files or another destination.

## Important limitation

This archive is an Xcode project, not a built or signed `.ipa`. An installable IPA must be compiled with Apple's iOS SDK and signed with an appropriate certificate/provisioning profile. This build environment does not have Xcode or the iOS SDK, so it cannot honestly produce a working signed IPA here.

Keep a backup of your original save. Save compatibility is not guaranteed; this tool patches supported fields and exports a file for you to manage manually.
